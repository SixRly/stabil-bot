
const TextoDoBemvindo = (prefix) => {
  
return `
•••••••••••••••••••••••••••••••••••••••••


entrou



•••••••••••••••••••••••••••••••••••••••••
`}

exports.TextoDoBemvindo = TextoDoBemvindo

const TextoDoSaiu = (prefix) => {
  
return `
•••••••••••••••••••••••••••••••••••••••••


saiu


•••••••••••••••••••••••••••••••••••••••••
`}

exports.TextoDoSaiu = TextoDoSaiu
