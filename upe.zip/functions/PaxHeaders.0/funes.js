31 path=functions/funções.js
